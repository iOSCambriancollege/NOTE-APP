

import UIKit

class ViewController: UIViewController {
    
    
    static var itmstr : Itmstr!
    var selectedItm : Itm!
    
    @IBOutlet weak var tableview: UITableView!
    
    
    override func viewDidLoad(){
        super.viewDidLoad()
        ViewController.itmstr = Itmstr()
        tableview.delegate = self
        tableview.dataSource = self
        
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        var lastData = ViewController.itmstr.itmarr.last
        if lastData?.f1 == "" {
            ViewController.itmstr.itmarr.removeLast()
        }
        tableview.reloadData()
    }
    
    @IBAction func AddButton(_ sender: Any) {
       
        
        
//        var userIdTextField: UITextField?
//        
//        let alert = UIAlertController(title: "Add Item", message: "", preferredStyle: .alert)
//        alert.addTextField { (textField) -> Void in
//            
//            userIdTextField = textField
//            userIdTextField?.placeholder = "Write an Item"
//        }
//        
//        
//        let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
//            
//            if let userInput = userIdTextField!.text {
//                itm.f1 = userInput
//                ViewController.itmstr.itmarr.append(itm)
//                self.tableview.reloadData()
//                _ =  ViewController.itmstr.svchnges()
//            }
//        })
//        
//        // Create Cancel button with action handlder
//        let cancel = UIAlertAction(title: "Cancel", style: .cancel) { (action) -> Void in
//            print("Cancel button tapped")
//        }
//        
//        //Add OK and Cancel button to dialog message
//        alert.addAction(ok)
//        alert.addAction(cancel)
//        self.present(alert, animated: true, completion: nil)
        
        
        
        
    }
}

extension ViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ViewController.itmstr.itmarr.count
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle:UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            let warning = UIAlertController(title: "Delete", message: "Are You Sure To Delete", preferredStyle: .actionSheet)
            let dismiss = UIAlertAction(title: "Cancel", style: .cancel, handler: nil).self
            
            let remove = UIAlertAction(title: "Delete", style: .destructive){_ in DispatchQueue.main.async {
                ViewController.itmstr.itmarr.remove(at: indexPath.row)
                ViewController.itmstr.svchnges()
                self.tableview.deleteRows(at: [indexPath], with: .automatic)
                self.tableview.reloadData()
            }}
            
            warning.addAction(dismiss)
            warning.addAction(remove)
        
            present(warning, animated: true, completion: nil)
        }
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "Cell", for:indexPath)
        cell.textLabel?.text = ViewController.itmstr.itmarr[indexPath.row].f1
        return cell
    }
    


    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "NoteData" {
                if let indexPath = tableview.indexPathForSelectedRow {
                    let selectedItem = ViewController.itmstr.itmarr[indexPath.row]
                                if let secondViewController = segue.destination as? NoteViewController {
                                    secondViewController.selectedNoteIndex = indexPath.row
                                    secondViewController.selectedNote = selectedItem
                                }
                            }
            }
        if segue.identifier == "NewNoteData" {
                            if let secondViewController = segue.destination as? NoteViewController {
                                let itm = Itm()
                                itm.f1 = ""
                                ViewController.itmstr.itmarr.append(itm)
                                secondViewController.selectedNoteIndex = ViewController.itmstr.itmarr.count - 1
                                secondViewController.selectedNote = itm
                            }
                        
        }

        }

   
    
}


extension UIView {
    func showToast(message: String, duration: TimeInterval = 3.0) {
        let toastLabel = UILabel(frame: CGRect(x: self.frame.size.width/2 - 75, y: self.frame.size.height-100, width: 150, height: 35))
        toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        toastLabel.textColor = UIColor.white
        toastLabel.textAlignment = .center;
        toastLabel.text = message
        toastLabel.alpha = 1.0
        toastLabel.layer.cornerRadius = 10;
        toastLabel.clipsToBounds  =  true
        self.addSubview(toastLabel)
        UIView.animate(withDuration: duration, delay: 0.1, options: .curveEaseOut, animations: {
            toastLabel.alpha = 0.0
        }, completion: {(isCompleted) in
            toastLabel.removeFromSuperview()
        })
    }
}
