//
//  NoteViewController.swift
//  Lab 7
//
//  Created by Keyur on 2023-11-22.
//

import Foundation
import UIKit

class NoteViewController: UIViewController {
    
    var selectedNoteIndex: Int?
    var selectedNote : Itm?
    
    
    @IBOutlet weak var noteTextView: UITextView!
     
    override func viewDidLoad() {
            super.viewDidLoad()
            
        if let selectedNoteIndex = selectedNoteIndex {
            let selectedItem = ViewController.itmstr.itmarr[selectedNoteIndex]
             
            noteTextView.text = selectedItem.f1
        
                print(noteTextView.text)
                // Use the received data in this view controller
                print("Received data: \(selectedNote)")
                
             
        }
    }
    
    @IBAction func saveEdittedNote(_ sender: Any) {
        if let data = noteTextView.text {
            if(selectedNote?.f1 != noteTextView.text){
                let itm = Itm()
                itm.f1 = data
                ViewController.itmstr.itmarr[selectedNoteIndex!] =  itm
               var result =  ViewController.itmstr.svchnges()
                if(result){
                    self.view.showToast(message: "Saved")
                }
            }
        }
        
    }
    
}
