

import Foundation

class Itm : NSObject, NSSecureCoding{
    
    
    static var supportsSecureCoding: Bool{
        get {
            return true
        }
    }
    var f1 : String
   
    
    override init(){
        f1 = ""
        
        super.init()
    }
    func encode(with coder: NSCoder) {
        coder.encode(f1, forKey: "f1")
        
    }
    
    required init?(coder: NSCoder) {
        f1 = coder.decodeObject(forKey: "f1") as! String
        
        super.init()
    }
    
}
